class FarmersController < ApplicationController
  def create
    @farmer = Farmer.new(farmer_params)
    if @farmer.save
      previous_income = REDIS.get('total_farmer_income') || 0
      REDIS.set('total_farmer_income', previous_income.to_i + @farmer.income.to_i)
      previous_land = REDIS.get('total_farmer_land') || 0
      REDIS.set('total_farmer_land', previous_land.to_i + @farmer.average_land.to_i)

      render json: { id: @farmer.id }, status: :created
    else
      render json: { errors: @farmer.errors.full_messages }, status: :unprocessable_entity
    end
  end
  def update
    @farmer = Farmer.find(params[:id])
    farmer_last_income = @farmer.income
    farmer_last_land = @farmer.average_land
    abc = @farmer.update(first_name: params[:form][:firstName], last_name: params[:form][:lastName], phone_number: params[:form][:phoneNumber], relation: params[:form][:relation],
    guardian_name: params[:form][:relationName], gender: params[:form][:gender].to_s.downcase, date_of_birth:params[:form][:dateOfBirth], average_land: params[:form][:land],
                          kit_distributed: params[:form][:isKitDistributed], income: params[:form][:income])

    location = @farmer.location

    xyz = location.update(state_id: params[:selectedLocation][:state], district_id: params[:selectedLocation][:district], block_id: params[:selectedLocation][:block], village_id: params[:selectedLocation][:village])

    if abc && xyz
      previous_income = REDIS.get('total_farmer_income') || 0
      REDIS.set('total_farmer_income', previous_income.to_i + @farmer.income.to_i - farmer_last_income)
      previous_land = REDIS.get('total_farmer_land') || 0
      REDIS.set('total_farmer_land', previous_land.to_i + @farmer.average_land.to_i - farmer_last_land)
      render json: { id: @farmer.id }, status: :ok
    else
      render json: { errors: @farmer.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def destroy
    farmer = Farmer.find(params[:id])
    FarmerImage.where(farmer_id: params[:id]).destroy_all if farmer.present?
    if farmer.present?
      location = farmer.location
      previous_income = REDIS.get('total_farmer_income') || 0
      REDIS.set('total_farmer_income', previous_income.to_i - farmer.income.to_i)
      previous_land = REDIS.get('total_farmer_land') || 0
      REDIS.set('total_farmer_land', previous_land.to_i - farmer.average_land.to_i)

      farmer.destroy
      if Farmer.where(location_id: location&.id).count < 1
        location.destroy if location.present?
      end
      render json: { success: true }, status: :ok
      return
    end
    render json: { success: false }, status: :bad_request
  end

  def signed_url
    farmer = Farmer.find(params[:id])
    filename = "#{farmer.id}_#{Time.now.to_i}_#{SecureRandom.hex(6)}#{File.extname(params[:filename])}"
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_upload_url(filename)
    render json: { signed_url: signed_url, image_url: filename }
  end
  def images
    farmer = Farmer.find(params[:id])
    images = farmer.farmer_images.map do |image|
      {
        id: image.id,
        image_url: image.image_url,    #gives name of image saved in table
        created_at: image.created_at,
      }
    end
    render json: images
  end

  def display_images
    farmer = Farmer.find(params[:id])
    s3_service = AwsS3Service.new
    images = farmer.farmer_images.map do |image|
      {
        id: image.id,
        full_image_url: s3_service.generate_view_url(image.image_url),  #gives actual image url
        created_at: image.created_at
      }
    end
    render json: images
  end

  def create_image
    farmer = Farmer.find(params[:id])
    image = FarmerImage.create(image_url: params[:image_url], user_id: current_user.id, farmer_id: farmer.id)
    # image = farmer.farmer_images.new(image_url: params[:image_url], user: current_user)
    if image
      render json: { message: 'Image saved successfully' }, status: :created
    else
      render json: { errors: image.errors.full_messages }, status: :unprocessable_entity
    end
  end


  def view_image
    farmer = Farmer.find(params[:id])
    image = farmer.farmer_images.find(params[:image_id])
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_view_url(image.image_url)
    render json: { signed_url: signed_url }
  end

  def download_image
    farmer = Farmer.find(params[:id]) #change it and routes relatively
    image = farmer.farmer_images.find(params[:image_id])
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_download_url(image.image_url, 3600) # 1 hour
    render json: { signed_url: signed_url }
  end

  def generate_excel
    farmer = Farmer.find(params[:id])
    s3_service = AwsS3Service.new

    image_urls = farmer.farmer_images.map do |image|
      # Generate a signed URL that's valid for 7 days
      signed_url = s3_service.generate_view_url(image.image_url, 7 * 24 * 3600)
      [image.id, signed_url]
    end.to_h

    # Generate your Excel file here, using image_urls
    # ...

    send_data excel_data, filename: "farmer_#{farmer.id}_images.xlsx"
  end

  def delete_image
    farmer = Farmer.find(params[:id])
    image = farmer.farmer_images.find(params[:image_id])

    s3_service = AwsS3Service.new
    if s3_service.delete_file(image.image_url)
      image.destroy
      render json: { message: "Image successfully deleted" }, status: :ok
    else
      render json: { error: "Image not found in S3" }, status: :not_found
    end
  rescue Aws::S3::Errors::ServiceError => e
    render json: { error: "Failed to delete image: #{e.message}" }, status: :internal_server_error
  end

  private

  def farmer_params
    {
      first_name: params[:form][:firstName],
      last_name: params[:form][:lastName],
      phone_number: params[:form][:phoneNumber],
      relation: params[:form][:relation],
      guardian_name: params[:form][:relationName],
      gender: params[:form][:gender].to_s.downcase,
      date_of_birth: params[:form][:dateOfBirth],
      average_land: params[:form][:land],
      kit_distributed: params[:form][:isKitDistributed],
      location_id: extract_location_id(params[:selectedLocation]),
      crop_type: params[:form][:cropType],
      income: params[:form][:income],
      selected_crops: params[:selectedCrops],
      user_id: current_user.id
    }
  end
  def extract_location_id(selected_location)
    location = Location&.find_or_create_by(
      state_id: selected_location[:state],
      district_id: selected_location[:district],
      block_id: selected_location[:block],
      village_id: selected_location[:village],
      user_id: current_user.id
    )&.id
    location
  end
end

# Location.find_by(state_id:  1, district_id: 2, block_id: 10, village_id: 11, user_id: 4)
# location = Location.new(
#   state_id: 1,
#   district_id: 2,
#   block_id: 10,
#   village_id: 11,
#   user_id: 4
# )
#
# if location.save
#   puts "Location created successfully: #{location.id}"
# else
#   puts "Location creation failed: #{location.errors.full_messages}"
# end

