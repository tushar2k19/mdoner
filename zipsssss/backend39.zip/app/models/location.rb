class Location < ApplicationRecord
  has_many :farmers

  # Ensure the combination of state, district, block, village, and user is unique
  validates :state_id, :district_id, :block_id, :village_id, :user_id, presence: true
  validates :state_id, uniqueness: { scope: [:district_id, :block_id, :village_id, :user_id], message: "Location already exists for this user." }

  belongs_to :state
  belongs_to :district
  belongs_to :block
  belongs_to :village
  belongs_to :user
end
