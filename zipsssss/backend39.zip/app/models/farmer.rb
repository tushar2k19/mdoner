class Farmer < ApplicationRecord
  belongs_to :location
  belongs_to :user

  # Validations
  validates :first_name, :last_name, :phone_number, :relation, :guardian_name, :gender, :date_of_birth, :average_land, presence: true

  enum gender: { male: 0, female: 1, other: 2 }
  validates :gender, inclusion: { in: Farmer.genders.keys }

  has_many :farmer_images
end
