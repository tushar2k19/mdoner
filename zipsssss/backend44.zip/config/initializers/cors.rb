# Be sure to restart your server when you modify this file.

# Avoid CORS issues when API is called from the frontend app.
# Handle Cross-Origin Resource Sharing (CORS) in order to accept cross-origin Ajax requests.

# Read more: https://github.com/cyu/rack-cors

Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    origins "http://localhost:8081",
            "http://localhost:8080",
            "https://wadi-india.netlify.app",
            "https://wadii.netlify.app",
            "https://wadibackend.com",
            "https://www.wadibackend.com",
            "http://new-4-app-env.eba-ngsqgjtu.ap-south-1.elasticbeanstalk.com",
            "https://new-4-app-env.eba-ngsqgjtu.ap-south-1.elasticbeanstalk.com"

    resource "*",
             headers: :any,
             credentials: true,
             expose: %w[access-token expiry token-type Authorization],
             methods: [:get, :post, :put, :patch, :delete, :options, :head]
  end
end
