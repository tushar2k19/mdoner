class User < ApplicationRecord
  has_secure_password
  enum role: { agent: 0, admin: 1, super_admin: 2, farmer: 3 }

  validates :first_name, presence: true
  validates :last_name, presence: true
  validates :email, presence: true, uniqueness: true
  validates :phone, presence: true
  validates :password_digest, presence: true
  validates :role, presence: true
end
