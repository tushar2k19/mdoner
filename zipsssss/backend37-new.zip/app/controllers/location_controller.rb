class LocationController < ApplicationController

  def index
    level = params[:level]

    locations = case level
                when 'state'
                  State.all
                when 'district'
                  District.where(state_id: params[:state])
                when 'block'
                  Block.where(district_id: params[:district])
                when 'village'
                  Village.where(block_id: params[:block])
                else
                  []
                end

    render json: locations.select(:id, :name)
  end

  def last_location
    user_id = current_user.id
    last_location = get_last_location(user_id)
    render json: last_location
  end

  def update_last_location
    user_id = current_user.id
    store_last_location(user_id, location_params)
    head :ok
  end

  private

  def location_params
    params.require(:location).permit(:state, :district, :block, :village)
  end

  def store_last_location(user_id, location_data)
    REDIS.set("user:#{user_id}:last_location", location_data.to_json)
  end

  def get_last_location(user_id)
    # pp "user:#{user_id}:last_location"
    location_json = REDIS.get("user:#{user_id}:last_location")
    location_json ? JSON.parse(location_json) : nil
  end
end
