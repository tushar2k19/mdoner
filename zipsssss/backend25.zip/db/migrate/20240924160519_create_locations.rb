class CreateLocations < ActiveRecord::Migration[6.1]
  def change
    create_table :locations do |t|
      t.references :state, null: false, foreign_key: true  # Adds foreign key to states table
      t.references :district, null: false, foreign_key: true  # Adds foreign key to districts table
      t.references :block, null: false, foreign_key: true  # Adds foreign key to blocks table
      t.references :village, null: false, foreign_key: true  # Adds foreign key to villages table
      t.references :user, null: false, foreign_key: true  # Adds foreign key to users table

      t.timestamps
    end

    # Composite index on state, district, block, village, and user to ensure uniqueness per user
    add_index :locations, [:state_id, :district_id, :block_id, :village_id, :user_id], unique: true, name: 'index_locations_on_state_district_block_village_user'
  end
end
