class CreateVillages < ActiveRecord::Migration[6.1]
  def change
    create_table :villages do |t|
      t.string :name, null: false
      t.references :block, null: false, foreign_key: true

      t.timestamps
    end

    add_index :villages, [:block_id, :name], unique: true
  end
end
