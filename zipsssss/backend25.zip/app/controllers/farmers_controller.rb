class FarmersController < ApplicationController
  def create
    #location_id in farmer_params, fix it
    @farmer = Farmer.new(farmer_params)
    if @farmer.save
      render json: { id: @farmer.id }, status: :created
    else
      render json: { errors: @farmer.errors.full_messages }, status: :unprocessable_entity
    end
  end
  def update
    @farmer = Farmer.find(params[:id])
    abc = @farmer.update(first_name: params[:form][:firstName], last_name: params[:form][:lastName], phone_number: params[:form][:phoneNumber], relation: params[:form][:relation],
    guardian_name: params[:form][:relationName], gender: params[:form][:gender].to_s.downcase, date_of_birth:params[:form][:dateOfBirth], average_land: params[:form][:land],
                          kit_distributed: params[:form][:isKitDistributed])

    if abc
      render json: { id: @farmer.id }, status: :ok
    else
      render json: { errors: @farmer.errors.full_messages }, status: :unprocessable_entity
    end
  end
  # conversation = Conversation.find_by(profile_id: params[:id])
  # ConversationMessage.where(conversation_id: conversation.id).delete_all if conversation.present?
  # conversation.destroy if conversation.present?
  # Profile.find(params[:id])&.destroy
  # render json: { success: true }, status: :ok
  def destroy
    farmer = Farmer.find(params[:id])
    FarmerImage.where(farmer_id: params[:id]).destroy_all if farmer.present?
    pp"farmerrrr is present #{farmer}"
    if farmer.present?
      location = farmer.location
      farmer.destroy if farmer.present?
      # pp"farmerrrr is gone #{location.id}"
      if Farmer.where(location_id: location&.id).count < 1
        location.destroy if location.present?
        # pp "locationnnn #{Location.find(location.id)}"
      end
      # pp"both are gone #{Location.find(location&.id)}"
      render json: { success: true }, status: :ok
      return
    end
    render json: { success: false }, status: :bad_request
  end

  def signed_url
    farmer = Farmer.find(params[:id])
    filename = "#{farmer.id}_#{Time.now.to_i}_#{SecureRandom.hex(6)}#{File.extname(params[:filename])}"
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_upload_url(filename)
    render json: { signed_url: signed_url, image_url: filename }
  end

  def create_image
    farmer = Farmer.find(params[:id])
    image = FarmerImage.create(image_url: params[:image_url], user_id: current_user.id, farmer_id: farmer.id)
    # image = farmer.farmer_images.new(image_url: params[:image_url], user: current_user)
    if image
      render json: { message: 'Image saved successfully' }, status: :created
    else
      render json: { errors: image.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def show_image
    farmer_image = FarmerImage.find(params[:id])
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_view_url(farmer_image.image_url, 3600) # 1 hour
    render json: { signed_url: signed_url }
  end
  def view_image
    farmer_image = FarmerImage.find(params[:id])
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_view_url(farmer_image.image_url)
    render json: { signed_url: signed_url }
  end

  def download_image
    farmer = Farmer.find(params[:id]) #change it and routes relatively
    image = farmer.farmer_images.find(params[:image_id])
    s3_service = AwsS3Service.new
    signed_url = s3_service.generate_download_url(image.image_url, 3600) # 1 hour
    render json: { signed_url: signed_url }
  end

  def generate_excel
    farmer = Farmer.find(params[:id])
    s3_service = AwsS3Service.new

    image_urls = farmer.farmer_images.map do |image|
      # Generate a signed URL that's valid for 7 days
      signed_url = s3_service.generate_view_url(image.image_url, 7 * 24 * 3600)
      [image.id, signed_url]
    end.to_h

    # Generate your Excel file here, using image_urls
    # ...

    send_data excel_data, filename: "farmer_#{farmer.id}_images.xlsx"
  end

  def delete_image
    farmer = Farmer.find(params[:id])
    image = farmer.farmer_images.find(params[:image_id])

    s3_service = AwsS3Service.new
    if s3_service.delete_file(image.image_url)
      image.destroy
      render json: { message: "Image successfully deleted" }, status: :ok
    else
      render json: { error: "Image not found in S3" }, status: :not_found
    end
  rescue Aws::S3::Errors::ServiceError => e
    render json: { error: "Failed to delete image: #{e.message}" }, status: :internal_server_error
  end

  private

  def farmer_params
    {
      first_name: params[:form][:firstName],
      last_name: params[:form][:lastName],
      phone_number: params[:form][:phoneNumber],
      relation: params[:form][:relation],
      guardian_name: params[:form][:relationName],
      gender: params[:form][:gender].to_s.downcase,
      date_of_birth: params[:form][:dateOfBirth],
      average_land: params[:form][:land],
      kit_distributed: params[:form][:isKitDistributed],
      location_id: extract_location_id(params[:selectedLocation]),
      user_id: current_user.id
    }
  end
  def extract_location_id(selected_location)
    location = Location&.find_or_create_by(
      state_id: selected_location[:state],
      district_id: selected_location[:district],
      block_id: selected_location[:block],
      village_id: selected_location[:village],
      user_id: current_user.id
    )&.id
    location
  end
end

# Location.find_by(state_id:  1, district_id: 2, block_id: 10, village_id: 11, user_id: 4)
# location = Location.new(
#   state_id: 1,
#   district_id: 2,
#   block_id: 10,
#   village_id: 11,
#   user_id: 4
# )
#
# if location.save
#   puts "Location created successfully: #{location.id}"
# else
#   puts "Location creation failed: #{location.errors.full_messages}"
# end

