Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  root "refresh#index"

  controller :refresh do
    post 'refresh' => 'refresh#create'
  end

  controller :signin do
    post 'signin' => 'signin#create'
    delete 'signout' => 'signin#destroy'
  end
  controller :dashboard do
    get 'metrics' => 'dashboard#metrics'
    get 'blocks' => 'dashboard#blocks'
    get 'villages' => 'dashboard#villages'
    get 'agents' => 'dashboard#agents'
    get 'filtered_data' => 'dashboard#filtered_data'
    get 'farmers_data' => 'dashboard#farmers_data'
    get 'fetch_farmer_data' => 'dashboard#fetch_farmer_data'

  end

  # controller :location do
  #   get 'location' => 'location#index'
  #   get 'last_location' => 'location#last_location'
  #   post 'update_last_location' => 'location#update_last_location'
  # end
  resources :location, only: [:index] do
    collection do
      get 'last_location'
      post 'update_last_location'
    end
  end
    resources :farmers, only: [:create, :update, :destroy] do
      member do
        get 'signed_url'
        post 'images', to: 'farmers#create_image'
        get 'view', to: 'farmers#show_image'  #idher se jo id jaa rhi hai vo farmer_id hai
        get 'images/:image_id/download', to: 'farmers#download_image'
        delete 'images/:image_id', to: 'farmers#delete_image'
      end
    end
end
