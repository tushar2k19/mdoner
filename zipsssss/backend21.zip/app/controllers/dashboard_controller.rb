class DashboardController < ApplicationController
  # before_action :authorize_access_request!
  # before_action :authorize_user!

  def fetch_farmer_data
    farmer = Farmer.find(params['id'])
    gender = case farmer.gender
             when 'male'
               'Male'
             when 'female'
               'Female'
             when 'other'
               'Other'
             end
    form = {
      firstName: farmer.first_name,
      lastName: farmer.last_name,
      phoneNumber: farmer.phone_number,
      relation: farmer.relation,
      relationName: farmer.guardian_name,
      gender:  gender,
      age: calculate_age(farmer.date_of_birth),
      dateOfBirth:  farmer.date_of_birth,
      land: farmer.average_land,
      isKitDistributed: farmer.kit_distributed
    }
    render json: { form: form, location:  farmer.location }, status: :ok
  end
  def agents
    if current_user.role == 'agent'
      render json: { error: 'Unauthorized' }, status: :forbidden
    else
      # agents = User.where(role: "agent").pluck(:id, :first_name, :last_name)
      agents = User.all.pluck(:id, :first_name, :last_name)
      agent_details = agents.map { |id, fn, ln| { id: id, name: fn +" " +  ln } }
      render json: {agents: agent_details}, status: :ok
    end
  end

  def metrics(filter_applied = false)
    user = current_user
    if !filter_applied
      metrics = if user.role == 'agent'
                  [
                    { name: "total_registered", label: "Total Registered", value: Farmer.where(user_id: current_user.id).count, color: "blue" },
                    # { name: "total_blocks", label: "Total Blocks Covered", value: Location.where(user_id:current_user.id).select(:block_id).distinct.count, color: "green" },
                    { name: "total_villages", label: "Total Villages Covered", value: Location.where(user_id:current_user.id).select(:village_id).distinct.count, color: "green" },
                  ]
                  else
                  [
                    { name: "total_registered", label: "Total Registered", value: Farmer.count, color: "blue" },
                    # { name: "total_states", label: "Total States", value: 1, color: "green" },
                    # { name: "total_districts", label: "Total Districts", value: 1, color: "red" },
                    { name: "total_blocks", label: "Total Blocks", value: Location.select(:block_id).distinct.count, color: "orange" },
                    { name: "total_villages", label: "Total Villages", value: Location.select(:village_id).distinct.count, color: "purple" },
                    { name: "total_kits", label: "Kits Distributed", value: Farmer.where(kit_distributed: true).count, color: "green" },
                    { name: "total_land", label: "Total Land (Acre)", value: 20000, color: "green" }, # fix this
                    { name: "average_land", label: "Average Land (Acre)", value: 4.56, color: "green" } #fix this
                  ]
                end
    else
      metrics = if user.role == 'agent'
                  # farmers = Farmer.where(user_id:  current_user.id).all
                  locations = Location.where(user_id: current_user.id)
                  locations = locations.where(state_id:  params["state"]) if params["state"].present?
                  locations = locations.where(district_id: params["district"]) if params["district"].present?
                  locations = locations.where(block_id:  params["block"]) if params["block"].present?
                  locations = locations.where(village_id:  params["village"]) if params["village"].present?
                  locations = locations.pluck(:id)
                  farmers = Farmer.where(user_id:  current_user.id, location_id: locations)
                  [
                    { name: "total_registered", label: "Total Registered", value: farmers.count, color: "blue" },
                    { name: "total_villages", label: "Total Villages", value: locations.count, color: "purple" },
                  ]
                else
                  locations = Location.all
                  locations = locations.where(state_id:  params["state"]) if params["state"].present?
                  locations = locations.where(district_id: params["district"]) if params["district"].present?
                  locations = locations.where(block_id:  params["block"]) if params["block"].present?
                  locations = locations.where(village_id:  params["village"]) if params["village"].present?
                  locations = locations.where(user_id:  params["agent"]) if params["agent"].present?
                  locations = locations.pluck(:id)
                  farmers_count = Farmer.where(location_id: locations).count
                  farmers_agent_count = Farmer.where(location_id: locations).where(user_id:  params["agent"]).count if params["agent"].present?

                  arr = []
                  arr.push({ name: "total_registered", label: "Total Registered", value: farmers_count, color: "blue" }) unless params["agent"].present?
                  arr.push({ name: "total_registered", label: "Total Registered", value: farmers_agent_count, color: "blue" }) if params["agent"].present?
                  arr.push({ name: "total_blocks", label: "Total Blocks", value: Location.where(id: locations).select(:block_id).distinct.count, color: "orange" }) unless params["block"].present?
                  arr.push({ name: "total_villages", label: "Total Villages", value: Location.where(id: locations).select(:village_id).distinct.count, color: "orange" }) unless params["village"].present?
                  arr.push({ name: "total_agents", label: "Total LRPs", value: Farmer.where(location_id: locations).select(:user_id).distinct.count, color: "orange" }) unless params["agent"].present?
                  arr
                end
    end
    if !filter_applied
      render json: { visibleMetrics: metrics }, status: :ok
    else
      metrics
    end
  end

  def blocks
    # pp "curr = #{current_user.role} -> params => #{params}"

    if current_user.role == 'agent'
      paramss = JSON&.parse(params["district"])
      authorized_blocks = Location.where(user_id:current_user.id, district_id: paramss["id"]&.to_i).pluck(:block_id).uniq
      blocks = Block.where(id: authorized_blocks).pluck(:id, :name)
      formatted_blocks = blocks.map { |id, name| { id: id, name: name } }
      render json: { blocks: formatted_blocks }, status: :ok
    else
      paramss = JSON&.parse(params["district"])
      blocks = Block.where(district_id: paramss["id"]&.to_i).pluck(:id, :name).uniq
      formatted_blocks = blocks.map { |id, name| { id: id, name: name } }
      render json: { blocks: formatted_blocks }, status: :ok
    end
  end

  def villages

  end

  def farmers_data
    limit = 4
    page = params[:page].to_i
    offset = (page - 1) * limit
    # pp"role = #{current_user.role}, page = #{page}, offset = #{offset}"
    if current_user.role == 'agent'
      farmers = Farmer.where(user_id: current_user.id)
    else
      farmers = Farmer.all
      farmers = farmers.where(user_id:  params["agent"]) if params["agent"].present?
      # pp "farmer_count22 = #{farmers.count}"
    end

    # Apply location filters
    locations = Location.all
    # pp "locations11 = #{locations.count}"
    locations = locations.where(state_id: params["state"]) if params["state"].present?
    locations = locations.where(district_id: params["district"]) if params["district"].present?
    locations = locations.where(block_id: params["block"]) if params["block"].present?
    locations = locations.where(village_id: params["village"]) if params["village"].present?
    locations = locations.where(user_id: params["agent"]) if params["agent"].present?

    # Get location IDs after filters
    location_ids = locations.pluck(:id)


    # Filter farmers by location and paginate
    farmers = farmers.where(location_id: location_ids)
                     .includes(location: [:block, :village]) # Eager load associations
                     .limit(limit)
                     .offset(offset)
                     .order(created_at: :desc)

    # Build response data
    beneficiary = farmers.map do |farmer|
      location = farmer.location
      {
        id: farmer.id,
        name: "#{farmer.first_name} #{farmer.last_name}",
        dob: calculate_age(farmer.date_of_birth),
        phone: farmer.phone_number,
        block: location.block.name,
        village: location.village.name,
        image_count: FarmerImage.where(farmer_id: farmer.id).count,
        registration_number: "#{farmer.created_at.to_s.gsub(/-|:| /, '')[0..-4]}_#{farmer.id}",
        created_at: farmer.created_at,
      }
    end
    render json: { success: true, data: beneficiary, count: farmers.count }
  end


  def filtered_data
    metrics = metrics(true)
    render json: { visibleMetrics: metrics }
  end




  private

  def authorize_user!
    # Example logic to authorize users; customize based on your requirements
    unless current_user.role.in?(['agent', 'admin', 'super_admin'])  # Allow only agents and admins
      render json: { error: 'Unauthorized' }, status: :forbidden
    end
  end
  def calculate_age(date_of_birth)
    return unless date_of_birth # Check if date_of_birth is present
    today = Date.today
    age = today.year - date_of_birth.year
    # Adjust if the birthday hasn't occurred yet this year
    age -= 1 if today < date_of_birth + age.years
    age
  end

end


# def farmers_data
#   limit = 4
#   page = params[:page].to_i
#
#   if current_user.role == 'agent'
#     farmers = Farmer.where(user_id: current_user.id)
#     locations = Location.where(user_id: current_user.id)
#     locations = locations.where(state_id:  params["state"]) if params["state"].present?
#     locations = locations.where(district_id: params["district"]) if params["district"].present?
#     locations = locations.where(block_id:  params["block"]) if params["block"].present?
#     locations = locations.where(village_id:  params["village"]) if params["village"].present?
#     locations = locations.pluck(:id)
#     farmers = farmers.where(location_id: locations)
#
#     beneficiary = farmers.map do |farmer|
#       location = Location.find farmer.location_id
#       block_id = Location.find(location.id).block_id
#       village_id = Location.find(location.id).village_id
#       {
#         id: farmer.id,
#         name: farmer.first_name + " " + farmer.last_name,
#         dob: calculate_age(farmer.date_of_birth),
#         phone: farmer.phone_number,
#         block: Block.find(block_id).name,
#         village:  Village.find(village_id).name,
#         image_count: FarmerImage.where(farmer_id: farmer.id).count,
#         registration_number: (farmer.created_at.to_s.gsub(/-|:| /, '')[0..-4]).to_s + "_" + farmer.id.to_s,
#         created_at: farmer.created_at,
#       }
#     end
#     sorted_farmers = beneficiary.sort_by { |beneficiary| beneficiary[:created_at] }.reverse
#     start_index = (page - 1) * limit
#     end_index = page * limit - 1
#     paginated_data = sorted_farmers[start_index..end_index]
#     render json: { success: true, data: paginated_data, count: sorted_farmers.count }
#   else
#     farmers = farmers.all
#     locations = Location.all
#     locations = locations.where(state_id:  params["state"]) if params["state"].present?
#     locations = locations.where(district_id: params["district"]) if params["district"].present?
#     locations = locations.where(block_id:  params["block"]) if params["block"].present?
#     locations = locations.where(village_id:  params["village"]) if params["village"].present?
#     locations = locations.where(user_id:   params["agent"]) if params["agent"].present?
#     locations = locations.pluck(:id)
#     farmers = farmers.where(location_id: locations)
#     beneficiary = farmers.map do |farmer|
#       location = Location.find farmer.location_id
#       block_id = Location.find(location.id).block_id
#       village_id = Location.find(location.id).village_id
#       {
#         id: farmer.id,
#         name: farmer.first_name + " " + farmer.last_name,
#         dob: calculate_age(farmer.date_of_birth),
#         phone: farmer.phone_number,
#         block: Block.find(block_id).name,
#         village:  Village.find(village_id).name,
#         image_count: FarmerImage.where(farmer_id: farmer.id).count,
#         registration_number: (farmer.created_at.to_s.gsub(/-|:| /, '')[0..-4]).to_s + "_" + farmer.id.to_s,
#         created_at: farmer.created_at,
#       }
#     end
#     sorted_farmers = beneficiary.sort_by { |beneficiary| beneficiary[:created_at] }.reverse
#     start_index = (page - 1) * limit
#     end_index = page * limit - 1
#     paginated_data = sorted_farmers[start_index..end_index]
#     render json: { success: true, data: paginated_data, count: sorted_farmers.count }
#   end
# end
