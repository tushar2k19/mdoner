class CreateFarmers < ActiveRecord::Migration[7.0]
  def change
    create_table :farmers do |t|
      # t.string :salutation, null: false
      t.string :first_name, null: false
      t.string :last_name, null: false
      t.string :phone_number, null: false
      t.string :relation, null: false  # Either father or husband
      t.string :guardian_name, null: false  # Father's or Husband's Name
      t.integer :gender, null: false  # Enum for gender: { male: 0, female: 1, other: 2 }
      t.date :date_of_birth, null: false
      t.integer :average_land, null: false  # Land in acres
      t.boolean :kit_distributed, default: false
      t.references :location, null: false, foreign_key: true  # Reference to Location table
      t.references :user, null: false, foreign_key: true  # Reference to User table

      t.timestamps
    end

    add_index :farmers, [:first_name, :last_name]
    add_index :farmers, :guardian_name
    add_index :farmers, :phone_number
  end
end
