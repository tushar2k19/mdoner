class District < ApplicationRecord
  belongs_to :state
  has_many :blocks
  has_many :locations
  validates :name, presence: true
  validates :state_id, presence: true
end
