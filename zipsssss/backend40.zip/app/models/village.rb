class Village < ApplicationRecord
  belongs_to :block
  has_many :locations

  validates :name, presence: true
  validates :block_id, presence: true
end
