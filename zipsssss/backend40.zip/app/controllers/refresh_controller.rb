class RefreshController < ApplicationController
  # before_action :authorize_refresh_by_access_request!

  def index
    render json: {message: "hello backend40, adding frontend-url and our domains in cors, force_ssl made true, added cookies/request debug_controller, morelinks in cors and added in signincontoller, added partitioned: true in cookies, did force_ssl:true", }, status: :ok
  end
  def create
    session = JWTSessions::Session.new(payload: claimless_payload, refresh_by_access_allowed: true)
    tokens = session.refresh_by_access_allowed do
      raise JWTSessions::Errors::Unauthorized, 'Access denied brother'
    end

    response.set_cookie(JWTSessions.access_cookie,
                        value: tokens[:access],
                        httponly: true,
                        secure: Rails.env.production?,
                        same_site: Rails.env.production? ? :none : :lax, # SameSite policy based on environment
                        path: '/')

    # Set CSRF token in a non-HttpOnly cookie so it can be accessed via JS
    response.set_cookie('csrf_token',
                        value: tokens[:csrf],
                        httponly: false, # Accessible to JavaScript
                        secure: Rails.env.production?,
                        same_site: Rails.env.production? ? :none : :lax,
                        path: '/')

    render json: { csrf: tokens[:csrf] }
  end
end

# Started POST "/refresh" for ::1 at 2024-09-14 21:33:27 +0530
# Processing by RefreshController#create as HTML
# Parameters: {"refresh"=>{}}
# Completed 500 Internal Server Error in 1ms (ActiveRecord: 0.0ms | Allocations: 492)
