class DebugController < ActionController::API
  def cookies_info
    render json: {
      request_host: request.host,
      request_domain: request.domain,
      all_cookies: request.cookies.to_h,
      headers: {
        origin: request.headers['Origin'],
        host: request.headers['Host'],
        user_agent: request.headers['User-Agent']
      },
      ssl: request.ssl?,
      protocol: request.protocol,
      port: request.port
    }
  end

  def request_info
    render json: {
      host: request.host,
      domain: request.domain,
      protocol: request.protocol,
      original_url: request.original_url,
      ssl?: request.ssl?,
      port: request.port,
      headers: request.headers.to_h.select { |k, _| k.start_with?('HTTP_') },
      cookies_header: request.headers['HTTP_COOKIE'],
      all_cookies: request.cookies.to_h
    }
  end
end
